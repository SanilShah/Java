/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Payal
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
        
        
 public class myFrame extends javax.swing.JFrame {
       int index;
       ButtonGroup group = new ButtonGroup();
       JComboBox comboBox = new JComboBox();
       JTabbedPane tabbedPane = new JTabbedPane();

       
       //tabbedPane.addChangeListener(new ChangeListener() {
         //@Override;
         private void stateChanged(ChangeEvent ce) {
            
            index=tabbedPane.getSelectedIndex();
            System.out.println(index);
         }
        
    public myFrame() {
        initComponents();
        int index=tabbedPane.getSelectedIndex();
        System.out.println(index);
       
        tabbedPane.addChangeListener(new ChangeListener() {
         @Override
         public void stateChanged(ChangeEvent ce) {
            System.out.println("Tab " + (tabbedPane.getSelectedIndex() + 1) + " is selected");
            
         }
      });
        
        
       
        String filePath = "C:\\Users\\Payal\\Documents\\NetBeansProjects\\Ass1.2\\formData1.txt";
        File file= new File(filePath);
        try {
            BufferedReader fr = new BufferedReader(new FileReader(file));
            String[] columnName = new String[]{"SRN","Name","Addess","Email","Gender","Mobile","Department"};
            DefaultTableModel model = (DefaultTableModel)tabStudData.getModel();
            model.setColumnIdentifiers(columnName);
            Object[] tableLines;
            tableLines = fr.lines().toArray();
            for(int i=0;i < tableLines.length; i++)
            {
                String line = tableLines[i].toString().trim();
                String[] dataRow =line.split("\t");
                model.addRow(dataRow);
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(myFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String filePath1 = "C:\\Users\\Payal\\Documents\\NetBeansProjects\\Ass1.2\\formData2.txt";
        File file1 = new File(filePath1);
        try {
            BufferedReader fr = new BufferedReader(new FileReader(file1));
            String[] columnName = new String[]{"SRN","Name","Addess","Email","Occupation","Mobile"};
            DefaultTableModel model = (DefaultTableModel)tabParentData.getModel();
            model.setColumnIdentifiers(columnName);
            Object[] tableLines;
            tableLines = fr.lines().toArray();
            for(int i=0;i < tableLines.length; i++)
            {
                String line = tableLines[i].toString().trim();
                String[] dataRow =line.split("\t");
                model.addRow(dataRow);
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(myFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String filePath2 = "C:\\Users\\Payal\\Documents\\NetBeansProjects\\Ass1.2\\formData3.txt";
        File file2= new File(filePath2);
        try {
            BufferedReader fr = new BufferedReader(new FileReader(file2));
            String[] columnName = new String[]{"Name","Addess","Email","Mobile","Department"};
            DefaultTableModel model = (DefaultTableModel)tabStaffData.getModel();
            model.setColumnIdentifiers(columnName);
            Object[] tableLines;
            tableLines = fr.lines().toArray();
            for(int i=0;i < tableLines.length; i++)
            {
                String line = tableLines[i].toString().trim();
                String[] dataRow =line.split("\t");
                model.addRow(dataRow);
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(myFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        String filePath3 = "C:\\Users\\Payal\\Documents\\NetBeansProjects\\Ass1.2\\formData1.txt";
        File file3= new File(filePath3);
        try {
            BufferedReader fr = new BufferedReader(new FileReader(file3));
            String[] columnName = new String[]{"SRN","Name","Addess","Email","Gender","Mobile","Department"};
            DefaultTableModel model = (DefaultTableModel)tabActData.getModel();
            model.setColumnIdentifiers(columnName);
            Object[] tableLines;
            tableLines = fr.lines().toArray();
            for(int i=0;i < tableLines.length; i++)
            {
                String line = tableLines[i].toString().trim();
                String[] dataRow =line.split("\t");
                model.addRow(dataRow);
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(myFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        group.add(rbMale);
        group.add(rbFemale);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tfStudentName = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        taAddress = new javax.swing.JTextArea();
        tfEmail = new javax.swing.JTextField();
        tfMobile = new javax.swing.JTextField();
        btSubmit = new javax.swing.JButton();
        btUpdate = new javax.swing.JButton();
        btDelete = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        rbMale = new javax.swing.JRadioButton();
        rbFemale = new javax.swing.JRadioButton();
        jLabel6 = new javax.swing.JLabel();
        cbDepartment = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        tfSRN = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        tfParentName = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tfParentSRN = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        taParentAddress = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        tfParentEmail = new javax.swing.JTextField();
        tfOccupation = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        tfParentMobile = new javax.swing.JTextField();
        btParentSubmit = new javax.swing.JButton();
        btUpdate1 = new javax.swing.JButton();
        btDelete1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        tfStaffName = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        taStaffAddress = new javax.swing.JTextArea();
        jLabel16 = new javax.swing.JLabel();
        tfStaffEmail = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        cbStaffDepartment = new javax.swing.JComboBox<>();
        btStaffSubmit = new javax.swing.JButton();
        btStaffUpdate = new javax.swing.JButton();
        btStaffDelete = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        tfStaffMobile = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabStudData = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        tabParentData = new javax.swing.JTable();
        jScrollPane8 = new javax.swing.JScrollPane();
        tabStaffData = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabActData = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jTabbedPane1StateChanged(evt);
            }
        });
        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
        });

        jLabel1.setText("Enter the name:");

        tfStudentName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfStudentNameActionPerformed(evt);
            }
        });

        jLabel2.setText("Address:");

        jLabel3.setText("Email Id:");

        jLabel4.setText("Mobile  No.:");

        taAddress.setColumns(20);
        taAddress.setRows(5);
        jScrollPane1.setViewportView(taAddress);

        btSubmit.setText("Submit");
        btSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSubmitActionPerformed(evt);
            }
        });

        btUpdate.setText("Update");
        btUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btUpdateActionPerformed(evt);
            }
        });

        btDelete.setText("Delete");
        btDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDeleteActionPerformed(evt);
            }
        });

        jLabel5.setText("Gender:-");

        rbMale.setText("Male");
        rbMale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbMaleActionPerformed(evt);
            }
        });

        rbFemale.setText("Female");
        rbFemale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbFemaleActionPerformed(evt);
            }
        });

        jLabel6.setText("Department:-");

        cbDepartment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Computer", "ENTC", "Mechanical", "Civil" }));
        cbDepartment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbDepartmentActionPerformed(evt);
            }
        });

        jLabel7.setText("SRN:");

        tfSRN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfSRNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jLabel2))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel3)))
                        .addGap(55, 55, 55)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfStudentName, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfSRN, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(btSubmit)))
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfMobile, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(rbMale, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(rbFemale))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(btUpdate)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btDelete))
                                .addComponent(cbDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(282, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(24, 24, 24))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(tfSRN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tfStudentName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(rbMale)
                    .addComponent(rbFemale))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tfMobile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cbDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btSubmit)
                    .addComponent(btUpdate)
                    .addComponent(btDelete))
                .addContainerGap(106, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Student", jPanel1);

        jLabel8.setText("Name:");

        tfParentName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfParentNameActionPerformed(evt);
            }
        });

        jLabel9.setText("Address:");

        jLabel10.setText("SRN:");

        taParentAddress.setColumns(20);
        taParentAddress.setRows(5);
        jScrollPane4.setViewportView(taParentAddress);

        jLabel11.setText("Email ID:");

        jLabel12.setText("Occupation:");

        tfOccupation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfOccupationActionPerformed(evt);
            }
        });

        jLabel13.setText("Mobile No:");

        btParentSubmit.setText("Submit");
        btParentSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btParentSubmitActionPerformed(evt);
            }
        });

        btUpdate1.setText("Update");
        btUpdate1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btUpdate1ActionPerformed(evt);
            }
        });

        btDelete1.setText("Delete");
        btDelete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelete1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel8)
                            .addComponent(jLabel10))
                        .addGap(52, 52, 52)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfParentName)
                            .addComponent(tfParentSRN)
                            .addComponent(jScrollPane4)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel13))
                                .addGap(38, 38, 38)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tfOccupation)
                                    .addComponent(tfParentMobile)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(54, 54, 54)
                                .addComponent(tfParentEmail))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(btParentSubmit)
                        .addGap(42, 42, 42)
                        .addComponent(btUpdate1)
                        .addGap(49, 49, 49)
                        .addComponent(btDelete1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(261, 261, 261))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tfParentSRN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tfParentName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(tfParentEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(tfOccupation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(tfParentMobile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btParentSubmit)
                    .addComponent(btUpdate1)
                    .addComponent(btDelete1))
                .addContainerGap(63, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Parent", jPanel2);

        jLabel14.setText("Name:");

        tfStaffName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfStaffNameActionPerformed(evt);
            }
        });

        jLabel15.setText("Address:");

        taStaffAddress.setColumns(20);
        taStaffAddress.setRows(5);
        jScrollPane5.setViewportView(taStaffAddress);

        jLabel16.setText("Email ID:");

        jLabel17.setText("Department:");

        cbStaffDepartment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Computer", "ENTC", "Mechanical", "Civil" }));
        cbStaffDepartment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbStaffDepartmentActionPerformed(evt);
            }
        });

        btStaffSubmit.setText("Submit");
        btStaffSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btStaffSubmitActionPerformed(evt);
            }
        });

        btStaffUpdate.setText("Update");
        btStaffUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btStaffUpdateActionPerformed(evt);
            }
        });

        btStaffDelete.setText("Delete");
        btStaffDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btStaffDeleteActionPerformed(evt);
            }
        });

        jLabel18.setText("Mobile No:");

        tfStaffMobile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfStaffMobileActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(btStaffSubmit)
                        .addGap(54, 54, 54)
                        .addComponent(btStaffUpdate)
                        .addGap(55, 55, 55)
                        .addComponent(btStaffDelete))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15)
                            .addComponent(jLabel16)
                            .addComponent(jLabel18)
                            .addComponent(jLabel17))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbStaffDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tfStaffName, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tfStaffEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tfStaffMobile, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(242, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(tfStaffName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(jLabel15)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfStaffEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16))
                        .addGap(35, 35, 35))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel18)
                        .addComponent(tfStaffMobile, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbStaffDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btStaffUpdate)
                    .addComponent(btStaffDelete)
                    .addComponent(btStaffSubmit))
                .addContainerGap(186, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Staff", jPanel3);

        tabStudData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6l", "Title 7"
            }
        ));
        tabStudData.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tabStudData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabStudDataMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tabStudData);

        tabParentData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6"
            }
        ));
        jScrollPane7.setViewportView(tabParentData);

        tabStaffData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        jScrollPane8.setViewportView(tabStaffData);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Table", jPanel4);

        tabActData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7"
            }
        ));
        jScrollPane6.setViewportView(tabActData);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 596, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 260, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.getAccessibleContext().setAccessibleName("Student");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfStudentNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfStudentNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfStudentNameActionPerformed

    private void btSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSubmitActionPerformed
        System.out.println(tfStudentName.getText());
        System.out.println(taAddress.getText());
        System.out.println(tfEmail.getText());
        System.out.println(tfMobile.getText());
        
        String srn=tfSRN.getText().toString();
        String name=tfStudentName.getText().toString();
        String addr=taAddress.getText().toString();
        String mail=tfEmail.getText().toString();
        String mobile=tfMobile.getText().toString();
        String department=cbDepartment.getSelectedItem().toString();
        System.out.println(department);
        String gender;
        if (rbMale.isSelected()){
            gender="Male";
        }
        else
        {
            gender="Female";
        }
        
        
        String filePath = "C:\\Users\\Payal\\Documents\\NetBeansProjects\\test\\formData1.txt";
        File file= new File(filePath);
      
        try{
            FileWriter fw = new FileWriter("formData1.txt",true);
            fw.write(srn);
            fw.write("\t");
            fw.write(name);
            fw.write("\t");
            fw.write(addr);
            fw.write("\t");
            fw.write(mail);
            fw.write("\t");
            fw.write(gender);
            fw.write("\t");
            fw.write(mobile);
            fw.write("\t");
            fw.write(department);
            
            
            fw.write(System.getProperty("line.separator"));
            fw.close();
            tfSRN.setText("");
            tfStudentName.setText("");
            taAddress.setText("");
            tfEmail.setText("");
            tfMobile.setText("");
            group.clearSelection();
            
            String[] currRecord=new String[]{srn,name,addr,mail,gender,mobile,department};
            System.out.println(currRecord);
            
            DefaultTableModel model = (DefaultTableModel)tabStudData.getModel();
            model.addRow(currRecord);
            
                    
            
           
           }
        catch (Exception e){
            
            System.out.println(e);        
        }
        
        
       /*try {
            BufferedReader fr = new BufferedReader(new FileReader(file));
            String[] columnName = new String[]{"Name","Addess","Email","Mobile"};
            DefaultTableModel model = (DefaultTableModel)tabStudData.getModel();
            model.setColumnIdentifiers(columnName);
            Object[] tableLines;
            tableLines = fr.lines().toArray();
            for(int i=0;i < tableLines.length; i++)
            {
                String line = tableLines[i].toString().trim();
                String[] dataRow =line.split("\t");
                model.addRow(dataRow);
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(myFrame.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        
        System.out.println("Success..");  
                
        
    }//GEN-LAST:event_btSubmitActionPerformed

    private void tabStudDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabStudDataMouseClicked
       DefaultTableModel model = (DefaultTableModel)tabStudData.getModel();
       int selectedRowIndex=tabStudData.getSelectedRow();
       tfSRN.setText(model.getValueAt(selectedRowIndex,0).toString());
       tfStudentName.setText(model.getValueAt(selectedRowIndex,1).toString());
       taAddress.setText(model.getValueAt(selectedRowIndex,2).toString());
       tfEmail.setText(model.getValueAt(selectedRowIndex,3).toString());
       
       String gender=model.getValueAt(selectedRowIndex,4).toString();
       if(gender=="Male"){
           rbMale.setSelected(true);
           
       }
       else{
           rbFemale.setSelected(true);
       }
       
       tfMobile.setText(model.getValueAt(selectedRowIndex,5).toString());
       cbDepartment.setSelectedItem(model.getValueAt(selectedRowIndex,6).toString());
    }//GEN-LAST:event_tabStudDataMouseClicked

    private void btUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btUpdateActionPerformed
       
        
        try{
        DefaultTableModel model = (DefaultTableModel)tabStudData.getModel();
        int selectedRowIndex=tabStudData.getSelectedRow();
        String newSRN=tfSRN.getText().toString();
        String newName=tfStudentName.getText().toString();
        String newAddr=taAddress.getText().toString();
        String newMail=tfEmail.getText().toString();
        String newMobile=tfMobile.getText().toString();
        String newDepartment=cbDepartment.getSelectedItem().toString();
        String newGender;
        
         if (rbMale.isSelected()){
            newGender="Male";
        }
        else
        {
            newGender="Female";
        }
        model.setValueAt(newSRN,selectedRowIndex,0);
        model.setValueAt(newName,selectedRowIndex,1);
        model.setValueAt(newAddr,selectedRowIndex,2);
        model.setValueAt(newMail,selectedRowIndex,3);
        model.setValueAt(newGender,selectedRowIndex,4);
        model.setValueAt(newMobile,selectedRowIndex,5);
        model.setValueAt(newDepartment,selectedRowIndex,6);
        
            tfSRN.setText("");
            tfStudentName.setText("");
            taAddress.setText("");
            tfEmail.setText("");
            tfMobile.setText("");
            group.clearSelection();
            
        System.out.println(tabStudData.getRowCount());
        FileWriter fw = new FileWriter("formData1.txt");
        
        for(int i=0; i<tabStudData.getRowCount(); i++)
        {
            String srn=model.getValueAt(i,0).toString();
            String name= model.getValueAt(i,1).toString();
            System.out.println(name);
            String addr=model.getValueAt(i,2).toString();
            System.out.println(addr);
            String mail=model.getValueAt(i,3).toString();
            String gender=model.getValueAt(i,4).toString();
            String mobile= model.getValueAt(i,5).toString();
            String department= model.getValueAt(i,6).toString();
            try{
            fw.write(srn);
            fw.write("\t");
            fw.write(name);
            fw.write("\t");
            fw.write(addr);
            fw.write("\t");
            fw.write(mail);
            fw.write("\t");
            fw.write(gender);
            fw.write("\t");
            fw.write(mobile);
             fw.write(gender);
            fw.write("\t");
            fw.write(System.getProperty("line.separator"));
            
            }
            catch(Exception e){
                System.out.println(e);
                
            }
        }
        fw.close();
        
        JOptionPane.showMessageDialog(rootPane,"Succesfully Updated..");
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null,ex);
            
        }
        
        
        
    }//GEN-LAST:event_btUpdateActionPerformed

    private void rbMaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbMaleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbMaleActionPerformed

    private void rbFemaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbFemaleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbFemaleActionPerformed

    private void cbDepartmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbDepartmentActionPerformed
        
    }//GEN-LAST:event_cbDepartmentActionPerformed

    private void tfSRNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfSRNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfSRNActionPerformed

    private void tfParentNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfParentNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfParentNameActionPerformed

    private void btParentSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btParentSubmitActionPerformed
        String srn=tfParentSRN.getText().toString();
        String name=tfParentName.getText().toString();
        String addr=taParentAddress.getText().toString();
        String mail=tfParentEmail.getText().toString();
        String occupation=tfOccupation.getText().toString();
        String mobile=tfParentMobile.getText().toString();
        
        System.out.println(srn);
        System.out.println(name);
        System.out.println(addr);
        System.out.println(mail);
        System.out.println(occupation);
        System.out.println(mobile);
        
        String filePath = "C:\\Users\\Payal\\Documents\\NetBeansProjects\\Ass1.2\\formData2.txt";
        File file= new File(filePath);
      
        try{
            FileWriter fp = new FileWriter("formData2.txt",true);
            fp.write(srn);
            fp.write("\t");
            fp.write(name);
            fp.write("\t");
            fp.write(addr);
            fp.write("\t");
            fp.write(mail);
            fp.write("\t");
            fp.write(occupation);
            fp.write("\t");
            fp.write(mobile);
            fp.write(System.getProperty("line.separator"));
            fp.close();
            
            tfParentSRN.setText("");
            tfParentName.setText("");
            taParentAddress.setText("");
            tfParentEmail.setText("");
            tfParentMobile.setText("");
            tfOccupation.setText("");
            
            String[] currRecord=new String[]{srn,name,addr,mail,occupation,mobile};
            System.out.println(currRecord);
            DefaultTableModel model = (DefaultTableModel)tabParentData.getModel();
            model.addRow(currRecord);
            
           }
        catch (Exception e){
            
            System.out.println(e);        
        }
    }//GEN-LAST:event_btParentSubmitActionPerformed

    private void btUpdate1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btUpdate1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btUpdate1ActionPerformed

    private void btDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDeleteActionPerformed
        try{
            DefaultTableModel model = (DefaultTableModel)tabStudData.getModel();
            int selectedRowIndex=tabStudData.getSelectedRow();
            model.removeRow(selectedRowIndex);
            FileWriter fw = new FileWriter("formData1.txt");
            tfSRN.setText("");
            tfStudentName.setText("");
            taAddress.setText("");
            tfEmail.setText("");
            tfMobile.setText("");
            group.clearSelection();

            for(int i=0; i<tabStudData.getRowCount(); i++)
            {
                String srn=model.getValueAt(i,0).toString();
                String name= model.getValueAt(i,1).toString();
                System.out.println(name);
                String addr=model.getValueAt(i,2).toString();
                System.out.println(addr);
                String mail=model.getValueAt(i,3).toString();
                String gender=model.getValueAt(i,4).toString();
                String mobile= model.getValueAt(i,5).toString();
                String department= model.getValueAt(i,6).toString();
                try{
                    fw.write(srn);
                    fw.write("\t");
                    fw.write(name);
                    fw.write("\t");
                    fw.write(addr);
                    fw.write("\t");
                    fw.write(mail);
                    fw.write("\t");
                    fw.write(gender);
                    fw.write("\t");
                    fw.write(mobile);
                    fw.write(gender);
                    fw.write("\t");
                    fw.write(System.getProperty("line.separator"));

                }
                catch(Exception e){
                    System.out.println(e);

                }
            }
            fw.close();

            JOptionPane.showMessageDialog(rootPane,"Succesfully Deleted..");
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,ex);
        }

    }//GEN-LAST:event_btDeleteActionPerformed

    private void btDelete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelete1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btDelete1ActionPerformed

    private void tfStaffNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfStaffNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfStaffNameActionPerformed

    private void cbStaffDepartmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbStaffDepartmentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbStaffDepartmentActionPerformed

    private void tfOccupationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfOccupationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfOccupationActionPerformed

    private void btStaffSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btStaffSubmitActionPerformed
        
        String name=tfStaffName.getText().toString();
        String addr=taStaffAddress.getText().toString();
        String mail=tfStaffEmail.getText().toString();
        String mobile=tfStaffMobile.getText().toString();
        String department=cbStaffDepartment.getSelectedItem().toString();
        
        
        String filePath = "C:\\Users\\Payal\\Documents\\NetBeansProjects\\test\\formData3.txt";
        File file= new File(filePath);
      
        try{
            FileWriter fw = new FileWriter("formData3.txt",true);
            
            fw.write(name);
            fw.write("\t");
            fw.write(addr);
            fw.write("\t");
            fw.write(mail);
            fw.write("\t");
            fw.write(mobile);
            fw.write("\t");
            fw.write(department);
            
            
            fw.write(System.getProperty("line.separator"));
            fw.close();
            
            tfStaffName.setText("");
            taStaffAddress.setText("");
            tfStaffEmail.setText("");
            tfStaffMobile.setText("");
            
            
            String[] currRecord=new String[]{name,addr,mail,mobile,department};
            System.out.println(currRecord);
            
            DefaultTableModel model = (DefaultTableModel)tabStaffData.getModel();
            model.addRow(currRecord);
            
                    
            
           
           }
        catch (Exception e){
            
            System.out.println(e);        
        }
        
    }//GEN-LAST:event_btStaffSubmitActionPerformed

    private void btStaffUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btStaffUpdateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btStaffUpdateActionPerformed

    private void btStaffDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btStaffDeleteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btStaffDeleteActionPerformed

    private void tfStaffMobileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfStaffMobileActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfStaffMobileActionPerformed
    
   
    private void jTabbedPane1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jTabbedPane1StateChanged
       
         index=tabbedPane.getSelectedIndex();
         System.out.println(index);
        
        DefaultTableModel model = (DefaultTableModel)tabActData.getModel();
        model.setRowCount(0);
        
        if(index==0){
            String filePath = "C:\\Users\\Payal\\Documents\\NetBeansProjects\\Ass1.2\\formData1.txt";
            File file= new File(filePath);
            try {
                BufferedReader fr = new BufferedReader(new FileReader(file));
                String[] columnName = new String[]{"SRN","Name","Addess","Email","Gender","Mobile","Department"};
                DefaultTableModel model_1 = (DefaultTableModel)tabActData.getModel();
                model_1.setColumnIdentifiers(columnName);
                Object[] tableLines;
                tableLines = fr.lines().toArray();
                for(int i=0;i < tableLines.length; i++)
                {
                    String line = tableLines[i].toString().trim();
                    String[] dataRow =line.split("\t");
                    model_1.addRow(dataRow);
                }

            } catch (FileNotFoundException ex) {
                Logger.getLogger(myFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
       }
       else{
          model.setRowCount(0);  
       }
        
        
      
    }//GEN-LAST:event_jTabbedPane1StateChanged

    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTabbedPane1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(myFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(myFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(myFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(myFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new myFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btDelete;
    private javax.swing.JButton btDelete1;
    private javax.swing.JButton btParentSubmit;
    private javax.swing.JButton btStaffDelete;
    private javax.swing.JButton btStaffSubmit;
    private javax.swing.JButton btStaffUpdate;
    private javax.swing.JButton btSubmit;
    private javax.swing.JButton btUpdate;
    private javax.swing.JButton btUpdate1;
    private javax.swing.JComboBox<String> cbDepartment;
    private javax.swing.JComboBox<String> cbStaffDepartment;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JRadioButton rbFemale;
    private javax.swing.JRadioButton rbMale;
    private javax.swing.JTextArea taAddress;
    private javax.swing.JTextArea taParentAddress;
    private javax.swing.JTextArea taStaffAddress;
    private javax.swing.JTable tabActData;
    private javax.swing.JTable tabParentData;
    private javax.swing.JTable tabStaffData;
    private javax.swing.JTable tabStudData;
    private javax.swing.JTextField tfEmail;
    private javax.swing.JTextField tfMobile;
    private javax.swing.JTextField tfOccupation;
    private javax.swing.JTextField tfParentEmail;
    private javax.swing.JTextField tfParentMobile;
    private javax.swing.JTextField tfParentName;
    private javax.swing.JTextField tfParentSRN;
    private javax.swing.JTextField tfSRN;
    private javax.swing.JTextField tfStaffEmail;
    private javax.swing.JTextField tfStaffMobile;
    private javax.swing.JTextField tfStaffName;
    private javax.swing.JTextField tfStudentName;
    // End of variables declaration//GEN-END:variables
}
