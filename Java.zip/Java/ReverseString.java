import java.util.Scanner;

public class ReverseString
{

	public static String reverse( String s)
	{
		char[] temp = s.toCharArray();
		char[] temp2 = {};
		for (int i = temp.length - 1, j = 0; i>0 + 1; i--,j++)
		{
			 temp2[j] = temp[i];  
		}
		String z = temp2.toString();
		return z;
	}

		
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter String: ");
		String input = sc.nextLine();
		String reverse = reverse(input);

		System.out.format(" Reversed String: %s", reverse);
	}	
}