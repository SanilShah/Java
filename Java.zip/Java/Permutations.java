import java.util.Scanner;

class Permutations
{

	public static void permute(String str, String ans)
	{
		if(str.length() == 0)
		{
			System.out.println(ans + " ");
		}
		
		for( int i = 0; i < str.length() ; i++  )
		{
			char c = str.charAt(i);
			String ros = str.substring(0,i) + str.substring(i+1);

			permute(ros, ans + c);
		}
	}	

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.print(" Enter String:");
		String s = sc.nextLine();
		permute(s,"");
	}
		
}