import javax.swing.*; //imports Swing package which creates form and button
import java.awt.event.*; //imports Event package which listens for button press

public class gui_test implements ActionListener { //notice implements ActionListener
    JButton button;

    public static void main (String[] args) {
        gui_test gui = new gui_test();
        gui.press();

    }

    public void press(){
        JFrame frame = new JFrame(); //creates a Java Frame called frame
        button = new JButton("geektechstuff.com"); //creates a Button called button
        button.addActionListener(this); //listens for button press
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //ends program when JFrame closed

        frame.getContentPane().add(button); //adds button to frame

        frame.setSize(200,200); //pixel size of frame in width then height

        frame.setVisible(true); //if false then frame will be invisible

    }

    public void actionPerformed(ActionEvent event){ //if button is pressed then this changes button text
        button.setText("I was pressed!");
    }

}