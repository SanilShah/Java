import javax.swing.JFrame; 
import javax.swing.JPanel;
import javax.swing.JLabel;  
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.io.FileWriter;

import java.awt.*;
import java.awt.event.*;

class StudentForm extends JFrame implements ActionListener{
	JTextField tfName,tfAddress,tfPhone;
	JButton btSubmit;

	public static void main(String args[]){
		StudentForm a = new StudentForm();
	}

	//Constructor
	public StudentForm(){
		//set title of jframe
		setTitle("Student form");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		//Creating object of jpanel class
		JPanel p = new JPanel();

		//set the layout
		p.setLayout(new GridBagLayout());

		//create constraints
		GridBagConstraints gbc = new GridBagConstraints();

		//insets for all conponents
		gbc.insets = new Insets(2,2,2,2);

		//Name
		gbc.gridx = 0;
		gbc.gridy = 0;
		p.add(new JLabel("Name"),gbc);

		gbc.gridx++;
		tfName = new JTextField("",20);
		p.add(tfName,gbc);

		//Address
		gbc.gridx=0;
		gbc.gridy++;
		p.add(new JLabel("Address"),gbc);

		gbc.gridx++;
		tfAddress = new JTextField("",20);
		p.add(tfAddress,gbc);

		//Phone
		gbc.gridx=0;
		gbc.gridy++;
		p.add(new JLabel("Phone"),gbc);

		gbc.gridx++;
		tfPhone = new JTextField("",20);
		p.add(tfPhone,gbc);

		//Submit button
		gbc.gridx=1;
		gbc.gridy++;
		btSubmit = new JButton("SUBMIT");
		btSubmit.addActionListener(this);
		p.add(btSubmit,gbc);

		//add the content
		getContentPane().add(p);

		setSize(600,400);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e)
	{
		try{
			FileWriter f = new FileWriter("student.txt", true);
			f.write(tfName.getText()+"\r\n");
			f.close();

			tfName.setText("");
		}
		catch(Exception xyz)
		{

		}
	}
}