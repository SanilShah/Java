import javax.swing.* ;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.FileReader;



class Form extends JFrame implements ActionListener
{
	JTextField tfName, tfAddress, tfPhone;
	JButton btSubmit;

	public static void main(String[] args)
	{
		Form a = new Form();
	}

	// Constructor
	public Form()
	{
		setTitle("Student Form");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		JPanel p = new JPanel();

		p.setLayout( new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.gridx = 0;
		gbc.gridy = 0;
		p.add( new JLabel("Name:"),gbc);

		gbc.gridx++;
		gbc.gridy = 0;
		tfName = new JTextField("",20);
		p.add(tfName,gbc);

		gbc.gridx = 0;
		gbc.gridy++;
		p.add( new JLabel("Address:"),gbc);

		gbc.gridx++;
		tfAddress = new JTextField("",20);
		p.add(tfAddress,gbc);

		gbc.gridx=0;
		gbc.gridy++;
		p.add( new JLabel("Phone:"),gbc);

		gbc.gridx++;
		tfPhone = new JTextField("",20);
		p.add(tfPhone,gbc);

		gbc.gridx = 0;
		gbc.gridy++;
		btSubmit = new JButton("Submit");
		btSubmit.addActionListener(this);
		p.add(btSubmit,gbc);

		getContentPane().add(p);

		setSize(600,500);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e)
	{
		try{
			FileWriter f = new FileWriter("student.txt", true);
			f.write(tfName.getText()+"\r\n");
			f.close();

			tfName.setText("");
		}
		catch(Exception xyz)
		{

		}
	}

}
