class test
{
   static String name = "sanil";
    static String phone  = "12345";

    public static void main(String[] args)
    {
        String a= "MY name is ";
        System.out.println("My name is" + name + "And my phno is " + phone);
    }
}