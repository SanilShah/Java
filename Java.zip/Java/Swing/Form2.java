import javax.swing.*;
import java.io.FileWriter;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.*;
import java.awt.event.*;

class Form2 extends JFrame implements ActionListener
{
	JTextField tfName,tfPhone;
	JButton btSubmit;

 	public static void main(String[] args)
	{
		Form2 a = new Form2();
	}

	public Form2()
	{

		setTitle("Form");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		JPanel p = new JPanel();
		
		p.setLayout(new GridBagLayout());
		GridBagConstraints gbc  = new GridBagConstraints();
		
		gbc.gridx = 0;
		gbc.gridy = 0;
		p.add( new JLabel("Name:"),gbc);

		gbc.gridx++;
		tfName = new JTextField("",20);
		p.add(tfName,gbc);

		gbc.gridx = 0;
		gbc.gridy++;
		p.add( new JLabel("Phone:"),gbc);	

		gbc.gridx++;
		tfPhone = new JTextField("",20);
		p.add(tfPhone,gbc);

		gbc.gridy++;
		btSubmit = new JButton("Submit");
		btSubmit.addActionListener(this);
		p.add(btSubmit,gbc);

		getContentPane().add(p);
			
		setSize(600,400);
		setVisible(true);
		

	}

	public void actionPerformed( ActionEvent e)
	{
		try
		{
			FileWriter f = new FileWriter("student.txt",true);
			f.write(tfName.getText() + "\n");
			f.write(tfPhone.getText() + "\n");

			f.close();
			tfName.setText("");
			tfPhone.setText("");
		}
		catch( Exception xyz)
		{}	
	}

}