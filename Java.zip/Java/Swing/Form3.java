import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;

class Form3 extends JFrame implements ActionListener
{
	JTextField tfname, tfphone;
	JButton btsubmit;

	public static void main(String[] args)
	{
		Form3 a = new Form3();
	}
	
	public Form3()
	{
		setTitle("Form3");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		JPanel p = new JPanel();
		p.setLayout(new GridBagLayout());
		
		GridBagConstraints gbc = new GridBagConstraints();

		gbc.gridx = 0;
		gbc.gridy = 0;
		p.add(new JLabel("Name:"),gbc);
		
		gbc.gridx++;
		tfname = new JTextField("",20);
		p.add(tfname,gbc);

		gbc.gridx = 0;
		gbc.gridy++;	
		p.add(new JLabel("Phone:"),gbc);
		
		gbc.gridx++;
		tfphone = new JTextField("",20);
		p.add(tfphone,gbc);

		gbc.gridy++;
		btsubmit = new JButton("Submit");
		btsubmit.addActionListener(this);
		p.add(btsubmit,gbc);

		getContentPane().add(p);
		setSize(600,400);
		setVisible(true);

	}	

	public void actionPerformed(ActionEvent e)
	{
		try
		{
			FileWriter f = new FileWriter("student.txt",true);
			f.write(tfname.getText() +",");
			f.close();	
			
		}
		catch(Exception xyz)
		{}
	}
}