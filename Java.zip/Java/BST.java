import java.util.Scanner;
class BST
{
	class node
	{
		int key;
		node left, right;
	
		public node( int item )
		{
			key = item;
			left = right = null; 
		}
	}
	
	node root;
	
	BST()
	{
		root = null;
	}

	void insert(int key)
	{
		root = insertRec( root, key );
	}

	node insertRec( node root, int key )
	{
		if(root==null)
		{
			root = new node(key);
			return root;
		}
		if(key < root.key)
		{
			root.left = insertRec(root.left, key);
		}
		else if( key > root.key)
			root.right = insertRec(root.right, key);

		return root;
	}

	void inorder()
	{
		inorderRec(root);
	}

	void inorderRec( node root )
	{
		if( root != null )
		{
		inorderRec(root.left);
		System.out.println(root.key);
		inorderRec(root.right);
		}
	}

	public static void main(String[] args)
	{
		BST tree = new BST();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 5 numbers:\n");
		for ( int i=0; i < 5; i++)
		{
			int no = sc.nextInt();
			tree.insert(no);
		}
		tree.inorder();
	}
}