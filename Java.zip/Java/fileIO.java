import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
class fileIO
{
	public static void main(String[] args) throws Exception 
	{
		FileReader f = new FileReader("input.txt");
		BufferedReader b = new BufferedReader(f);
		FileWriter fr = new FileWriter("input.txt",true);

		String i;
		i=b.readLine();
		String[] c = i.split(",");
		for ( int j = 0; j< c.length-1; j++)
			fr.write(c[j]);
		
		f.close();
		fr.close();
		b.close();
	}

}