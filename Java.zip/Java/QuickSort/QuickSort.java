public class QuickSort 
{

	public static void main(String args[])
	{
		int low, high, pivot;
		int arr[] = { 2,1,3,5,4,6,7,8,10,9 };
		

		System.out.println(" Before Sorting : " );
		for ( int i=0; i< arr.length; i++ )
		{
			System.out.println(  arr[i] + " ");
		}
		
		QuickSort.quicksort( arr, 0, arr.length - 1);
		
		System.out.println(" After Sorting : " );
		for ( int i=0; i< arr.length; i++ )
		{
			System.out.println(  arr[i] + " ");
		}
	}


	private static int partition( int arr[], int low, int high )
	{
		int pivot =  arr[high];
		int i = low - 1;

		for ( int j = low; j < high; j++ )
		{
			if( arr[j] < arr[pivot] )
			{
				i++;
				int temp = arr[i];		
				arr[i] = arr[j];		
				arr[j] = temp;
			}
		}
		
		int temp = arr[i+1];
		arr[i+1] = arr[high];
		arr[high] = temp;

		return (i + 1);

	}

	public static void quicksort( int arr[], int low, int high)
	{
		int p = 0;
			
		if ( low < high )
		{
			p = partition( arr, low, high );
			quicksort( arr, low, p - 1);
			quicksort( arr, p + 1, high);
		}
		
	}

}