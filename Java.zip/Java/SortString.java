import java.util.Scanner;

public class SortString
{

	public  static String ssort( String s )
	{
		if (s.length() == 2)
			return s;
		else
		{
			char min = s.charAt(0);
			int pos = 0;
			int length = s.length();

			for( int i = 0; i <length; i++ )
			{
				if ( s.charAt(i) < min )
				{
					min = s.charAt(i);		
					pos = i;
				}
			}
			return min + ssort(s.substring(0, pos) + s.substring(pos + 1));
		}
	}

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
	
		System.out.println(" Enter the String: ");
		String input  = sc.nextLine();
		String sorted = ssort(input);
		System.out.format("Sorted String: %s", sorted);
	}
}
