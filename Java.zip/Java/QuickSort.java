public class QuickSort extends Thread
{

	public static int numThreads = Runtime.getRuntime().availableProcessors();
	public static int count = 0;
	public int low, high, arr[];
		
	public static void main(String args[])
	{
		int low, high, pivot;
		int arr[] = { 9,8,7,6,5,4,3,2,1,0 };
		long start = System.currentTimeMillis();
		

		System.out.println(" Before Sorting : " );
		for ( int i=0; i< arr.length; i++ )
		{
			System.out.println(  arr[i] + " ");
		}
		
		QuickSort.quicksort( arr, 0, arr.length - 1);
		
		System.out.println(" After Sorting : " );
		for ( int i=0; i< arr.length; i++ )
		{
			System.out.println(  arr[i] + " ");
		}
		System.out.println(" Sorted in : " +(System.currentTimeMillis() - start) + " ms");
	}

	public QuickSort(int[] arr, int low, int high )	
	{
		this.arr = arr;
		this.low = low;
		this.high = high;	
	}

	private static int partition( int arr[], int low, int high )
	{
		int pivot =  arr[high];
		int i = low - 1;

		for ( int j = low; j < high; j++ )
		{
			if( arr[j] < pivot)
			{
				i++;
				int temp = arr[i];		
				arr[i] = arr[j];		
				arr[j] = temp;
			}
		}
		
		int temp = arr[i+1];
		arr[i+1] = arr[high];
		arr[high] = temp;

		return (i + 1);

	}

	public static void quicksort( int arr[], int low, int high)
	{
		int p = 0;
			
		if ( low < high )
		{
			p = partition( arr, low, high );
			quicksort( arr, low, p - 1);
			quicksort( arr, p + 1, high);
		}
		
	}

	public static void parallelQuicksort( int arr[], int low, int high)
	{
		int p = 0;	
		int defArr[] = {0,0};
		QuickSort lowT = new QuickSort(defArr, 0, 0);
		QuickSort highT = new QuickSort(defArr, 0, 0);	
		
		if ( low < high )
		{
			p = partition( arr, low, high );

			if( count < numThreads )
			{
				count++;
				lowT = new QuickSort(arr, low, p - 1);
				lowT.start();
			}
			else
				quicksort(arr, low, p - 1);


			if( count < numThreads )
			{
				count++;
				highT = new QuickSort(arr, p + 1, high);
				highT.start();
			}
			else
				quicksort( arr, p + 1, high);		
			
		}
		try
		{
			lowT.join();
		}
		catch( InterruptedException e){}

		try
		{
			highT.join();
		}
		catch( InterruptedException e){}

		
	}

	public void run()
	{
		parallelQuicksort(arr,low,high);
	}

}