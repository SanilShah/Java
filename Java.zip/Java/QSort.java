public class QSort implements Runnable
{
	int arr[],low,high;

	public QSort(int[] arr, int low, int high)
	{
		this.arr = arr;
		this.low = low;
		this.high = high;
	}


	public void run()
	{
		sort(this.arr,this.low,this.high);
	}

	public static int partition( int arr[], int low, int high)
	{
		int j = low - 1;
		int pivot = arr[high];
		for(int i=low;i < high; i++)
		{
			if( arr[i] < pivot)
			{
				j++;
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				
			}
		}
		int temp = arr[j+1];
		arr[j+1] = arr[high];
		arr[high] = temp;

		return (j+1);
	}

	public static void sort(int arr[], int low, int high)
	{
		int p = 0;

		if ( low < high)
		{
			p = partition(arr,low,high);
			sort(arr,low,p-1);
			sort(arr,p+1,high);
		}

	}
	


	public static void main(String[] args)
	{
		int arr[] = {9,8,7,6,5,4,3,2,1,0};
		int p, low, high;
		long start = System.currentTimeMillis();

		System.out.println("Sorted Array:\n");

		p = partition( arr, 0, arr.length-1);
		Thread t1 = new Thread( new QSort(arr,0,p-1));
		Thread t2 = new Thread( new QSort(arr,p+1,arr.length - 1));
		t1.start();
		t2.start();
		try
		{
			t1.join();
			t2.join();
		}
		catch(InterruptedException e)
		{
			System.out.println(e);
		}
		//sort(arr, 0 , arr.length - 1);
		for ( int i=0; i < arr.length ; i++)
		{
			System.out.println(arr[i] + " ");
		}
		System.out.println(" Sorted in : " +(System.currentTimeMillis() - start) + " ms");
	}

}