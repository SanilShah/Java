import java.util.Scanner;

public class palindrome
{
	public static void main(String args[])
	{
		String str;
		Scanner sc = new Scanner(System.in);
		int flag = 0;

		System.out.println("Enter String :");
		str = sc.nextLine();

		int length = str.length();

		for(int i = 0, j = length -1; i<=length/2 ; i++, j--)
		{
			if( str.charAt(i) != str.charAt(j) )
			{
				flag=1;
				break;
			}
		}
		
		if( flag == 0)
			System.out.println(str + " is a palindrome.");
		else
			System.out.println(str + " is not a palindome.");
	}
}